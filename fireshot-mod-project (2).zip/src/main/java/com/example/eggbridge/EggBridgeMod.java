package com.example.eggbridge;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.EggEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

// Мод "Мост-яйцо": бросил яйцо, и за ним по воздуху строится мост.
// Идея: следим за каждым летящим яйцом, и каждый тик (1/20 секунды)
// ставим блоки под тем местом, где яйцо сейчас находится.
public class EggBridgeMod implements ModInitializer {

    // Из чего строим мост. Можно заменить, например, на Blocks.OAK_PLANKS или Blocks.RED_WOOL
    public static final Block BRIDGE_BLOCK = Blocks.WHITE_WOOL;

    // Ширина моста: 0 = 1 блок, 1 = 3 блока, 2 = 5 блоков
    public static final int RADIUS = 1;

    // Сколько тиков яйцо летит и строит (20 тиков = 1 секунда). 40 = около 30 блоков моста
    public static final int MAX_TICKS = 40;

    // Скорость яйца: 1.0 = обычная. Меньше = медленнее. Слишком быстрое яйцо оставляет дырки в мосту.
    public static final double SPEED_MULTIPLIER = 0.6;

    // Список яиц, которые сейчас летят, и в каком мире каждое
    private static final Map<EggEntity, ServerWorld> FLYING_EGGS = new HashMap<>();

    @Override
    public void onInitialize() {
        // 1) Когда в мире появляется яйцо, запоминаем его (только если его бросил игрок)
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof EggEntity egg && egg.getOwner() instanceof PlayerEntity) {
                egg.setNoGravity(true); // яйцо летит ровно, не падает вниз
                egg.setVelocity(egg.getVelocity().multiply(SPEED_MULTIPLIER)); // чуть медленнее
                FLYING_EGGS.put(egg, world);
            }
        });

        // 2) Каждый тик обходим все летящие яйца и строим под ними мост
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Iterator<Map.Entry<EggEntity, ServerWorld>> it = FLYING_EGGS.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<EggEntity, ServerWorld> entry = it.next();
                EggEntity egg = entry.getKey();
                ServerWorld world = entry.getValue();

                // Яйцо во что-то попало и исчезло? Забываем про него
                if (egg.isRemoved()) {
                    it.remove();
                    continue;
                }

                // Яйцо летит слишком долго? Убираем
                if (egg.age > MAX_TICKS) {
                    egg.discard();
                    it.remove();
                    continue;
                }

                // Блок на 2 ниже яйца = на уровне "под ногами" бросившего игрока
                placeBridge(world, egg.getBlockPos().down(2));
            }
        });
    }

    // Ставит блоки полосой вокруг точки center (только там, где пусто)
    private static void placeBridge(ServerWorld world, BlockPos center) {
        boolean placedAny = false;
        for (int dx = -RADIUS; dx <= RADIUS; dx++) {
            for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                BlockPos pos = center.add(dx, 0, dz);
                if (world.getBlockState(pos).isAir()) { // не затираем существующие блоки
                    world.setBlockState(pos, BRIDGE_BLOCK.getDefaultState());
                    placedAny = true;
                }
            }
        }
        if (placedAny) {
            world.playSound(null, center, SoundEvents.BLOCK_WOOL_PLACE, SoundCategory.BLOCKS, 0.6f, 1.0f);
        }
    }
}
